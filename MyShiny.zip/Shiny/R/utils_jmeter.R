# =====================================================================
# R/utils_jmeter.R  -  the data engine (pure functions, no Shiny here)
# ---------------------------------------------------------------------
# Canonical internal schema every file is mapped to:
#   ts       POSIXct   sample time
#   elapsed  numeric   response time in MILLISECONDS (JMeter standard)
#   label    character transaction / sampler name
#   ok       logical   TRUE = success
#   code     character response code (optional, may be NA)
#   message  character response message (optional, may be NA)
#   threads  numeric   active threads (optional, may be NA)
# Works with raw JMeter CSVs AND custom exports (startTime / endTime /
# TimeToLastByte / sampleLabel / isSuccessful) by detecting columns by name.
# =====================================================================

# Candidate source columns for each canonical field, in priority order.
# Matching is case-insensitive.
.JM_CANDS <- list(
  time    = c("timestamp", "endtime", "starttime", "time"),
  elapsed = c("elapsed", "timetolastbyte", "responsetime", "latency"),
  label   = c("label", "samplelabel", "transaction", "name"),
  success = c("success", "issuccessful", "issuccsessful"),  # last one = a real-world typo
  code    = c("responsecode", "code", "statuscode"),
  message = c("responsemessage", "message", "failuremessage"),
  threads = c("allthreads", "grpthreads", "numberofactivethreads", "activethreads")
)

# Sniff the delimiter from the first non-empty line (text only, so ragged
# data rows can't confuse it). Returns one of , ; tab |.
jm_sniff_sep <- function(path) {
  ls <- readLines(path, n = 5L, warn = FALSE)
  ls <- ls[nzchar(trimws(ls))]
  if (!length(ls)) return(",")
  line1 <- sub("^\ufeff", "", ls[1])               # strip BOM if present
  cand   <- c(",", ";", "\t", "|")
  counts <- vapply(cand, function(d) length(strsplit(line1, d, fixed = TRUE)[[1]]) - 1L, integer(1))
  if (max(counts) <= 0) "," else cand[which.max(counts)]
}

# Read the header as plain text and split it ourselves. Far more reliable
# than the reader's auto-detection on JMeter files with ragged Txn_ rows.
jm_header <- function(path, sep = jm_sniff_sep(path)) {
  ls <- readLines(path, n = 5L, warn = FALSE)
  ls <- ls[nzchar(trimws(ls))]
  if (!length(ls)) return(character(0))
  line1 <- sub("^\ufeff", "", ls[1])
  parts <- strsplit(line1, sep, fixed = TRUE)[[1]]
  trimws(gsub('^"|"$', "", parts))                  # drop surrounding quotes
}

# Map header -> canonical source columns. Returns a named list; entries
# are the actual column name in the file, or NA if absent.
jm_detect_schema <- function(header) {
  lower <- tolower(trimws(header))
  pick <- function(cands) {
    for (c in cands) {
      i <- match(c, lower)
      if (!is.na(i)) return(header[i])
    }
    NA_character_
  }
  lapply(.JM_CANDS, pick)
}

# Essential columns must be present. Returns NULL if OK, else a message.
jm_validate_schema <- function(schema, header = NULL) {
  miss <- c(
    if (is.na(schema$time))    "a timestamp (timeStamp / endTime / startTime)",
    if (is.na(schema$elapsed)) "a response time (elapsed / TimeToLastByte)",
    if (is.na(schema$label))   "a label (label / sampleLabel)"
  )
  if (length(miss)) {
    found <- if (!is.null(header)) paste0(" Found columns: ", paste(header, collapse = ", ")) else ""
    paste0("This file is missing ", paste(miss, collapse = ", "), ".", found)
  } else NULL
}

# Derive the logical success vector from whatever the file provides.
.jm_success <- function(dt, schema) {
  if (!is.na(schema$success)) {
    v <- dt[[schema$success]]
    if (is.logical(v)) return(v)
    if (is.numeric(v)) return(v == 1)
    return(tolower(trimws(as.character(v))) %in% c("true", "t", "1", "yes", "y", "ok"))
  }
  if (!is.na(schema$code)) {                       # fall back to 2xx/3xx = success
    return(grepl("^[23]", as.character(dt[[schema$code]])))
  }
  rep(TRUE, nrow(dt))                              # nothing to go on -> assume success
}

# Fingerprint a file for the Parquet cache (name + size + mtime).
jm_fingerprint <- function(path, name) {
  info <- file.info(path)
  raw  <- paste(name, info$size, as.numeric(info$mtime), sep = "_")
  paste0("f", substr(rlang::hash(raw), 1, 16))
}

# Read the raw CSV FAST, keeping only the columns we actually use.
# fill = TRUE tolerates ragged rows, e.g. Txn_ rows whose unquoted
# responseMessage ("... : 1, number of failing : 0") adds an extra field.
.jm_read_raw <- function(path, schema, sep = "auto") {
  keep <- unique(stats::na.omit(unlist(schema, use.names = FALSE)))
  data.table::fread(path, select = keep, sep = sep, header = TRUE,
                    fill = TRUE, showProgress = FALSE)
}

# Convert a raw data.table to the canonical schema.
.jm_to_canonical <- function(raw, schema, tz) {
  raw_t <- as.numeric(raw[[schema$time]])
  # Auto-detect epoch units: ms (~1e12) vs seconds (~1e9).
  med <- stats::median(raw_t, na.rm = TRUE)
  if (is.finite(med) && med > 1e12) raw_t <- raw_t / 1000
  ts <- as.POSIXct(raw_t, origin = "1970-01-01", tz = tz)

  out <- data.table::data.table(
    ts      = ts,
    elapsed = as.numeric(raw[[schema$elapsed]]),
    label   = as.character(raw[[schema$label]]),
    ok      = .jm_success(raw, schema),
    code    = if (!is.na(schema$code))    as.character(raw[[schema$code]])    else NA_character_,
    message = if (!is.na(schema$message)) as.character(raw[[schema$message]]) else NA_character_,
    threads = if (!is.na(schema$threads)) as.numeric(raw[[schema$threads]])   else NA_real_
  )
  out[is.finite(elapsed) & !is.na(ts)]
}

# ---------------------------------------------------------------------
# Ingest orchestrator: parse-or-load-from-cache. Returns the UNFILTERED
# canonical data.table. Filtering (ramp-up / label exclude) is applied
# later and cheaply, so changing those settings does not re-parse.
# ---------------------------------------------------------------------
jm_ingest <- function(path, name, tz = "Pacific/Auckland", cache_dir = CACHE_DIR) {
  fp <- jm_fingerprint(path, name)
  pq <- file.path(cache_dir, paste0(fp, ".parquet"))

  if (file.exists(pq)) {
    dt <- data.table::as.data.table(arrow::read_parquet(pq))
  } else {
    sep    <- jm_sniff_sep(path)
    header <- jm_header(path, sep)
    schema <- jm_detect_schema(header)
    err <- jm_validate_schema(schema, header)
    if (!is.null(err)) stop(err, call. = FALSE)
    dt <- .jm_to_canonical(.jm_read_raw(path, schema, sep), schema, tz)
    if (!nrow(dt)) stop(
      "Read the header but found no usable rows. The file may use unusual quoting; ",
      "try the Manual column mapping panel.", call. = FALSE)
    arrow::write_parquet(dt, pq)               # cache for instant reload
  }
  data.table::setattr(dt$ts, "tzone", tz)      # display tz (instant is unchanged)
  dt[]
}

# ---------------------------------------------------------------------
# Manual mapping path (for files with NO header row or unusual layouts).
# ---------------------------------------------------------------------

# First few rows with columns named V1..Vn, so the user can map by position.
jm_preview <- function(path, n = 6L, sep = "auto") {
  dt <- data.table::fread(path, nrows = n, header = FALSE, fill = TRUE, sep = sep)
  data.table::setnames(dt, paste0("V", seq_len(ncol(dt))))
  dt[]
}

# Ingest using an explicit positional mapping. `mapping` is a named list
# (time, elapsed, label, success, code, message, threads) whose values are
# "V<k>" column ids ("" / NA when not mapped).
jm_ingest_mapped <- function(path, name, mapping, has_header = FALSE,
                             sep = "auto", tz = "Pacific/Auckland", cache_dir = CACHE_DIR) {
  pq <- file.path(cache_dir, paste0(jm_fingerprint(path, name), "_m.parquet"))
  if (file.exists(pq)) {
    dt <- data.table::as.data.table(arrow::read_parquet(pq))
  } else {
    raw <- data.table::fread(path, header = FALSE, fill = TRUE, sep = sep,
                             skip = if (has_header) 1L else 0L)
    data.table::setnames(raw, paste0("V", seq_len(ncol(raw))))
    schema <- lapply(mapping, function(v)
      if (is.null(v) || !nzchar(v) || !(v %in% names(raw))) NA_character_ else v)
    err <- jm_validate_schema(schema, names(raw))
    if (!is.null(err)) stop(err, call. = FALSE)
    dt <- .jm_to_canonical(raw, schema, tz)
    if (!nrow(dt)) stop(
      "Mapping produced no usable rows. Check that the Timestamp and Response time ",
      "columns hold numbers, and try forcing the Separator (e.g. comma).", call. = FALSE)
    arrow::write_parquet(dt, pq)
  }
  data.table::setattr(dt$ts, "tzone", tz)
  dt[]
}

# Cheap reactive-side filter: drop ramp-up window and excluded labels.
jm_filter <- function(dt, exclude_regex = "", rampup_min = 0) {
  if (nzchar(exclude_regex)) dt <- dt[!grepl(exclude_regex, label, perl = TRUE)]
  if (rampup_min > 0 && nrow(dt)) {
    t0 <- min(dt$ts, na.rm = TRUE)
    dt <- dt[ts >= t0 + rampup_min * 60]
  }
  dt
}

# ---------------------------------------------------------------------
# Aggregations  (all in data.table = fast even on tens of millions of rows)
# ---------------------------------------------------------------------

# Whole-run KPI summary. Response-time stats are in SECONDS.
jm_summary <- function(dt) {
  n     <- nrow(dt)
  dur_s <- as.numeric(difftime(max(dt$ts), min(dt$ts), units = "secs"))
  errs  <- sum(!dt$ok, na.rm = TRUE)
  s     <- dt$elapsed / 1000                       # ms -> seconds
  list(
    samples      = n,
    errors       = errs,
    error_pct    = if (n) 100 * errs / n else 0,
    throughput   = if (dur_s > 0) n / dur_s else NA_real_,
    duration_min = dur_s / 60,
    start        = min(dt$ts),
    end          = max(dt$ts),
    mean         = mean(s, na.rm = TRUE),
    median       = stats::median(s, na.rm = TRUE),
    p80          = stats::quantile(s, .80, na.rm = TRUE, names = FALSE),
    p90          = stats::quantile(s, .90, na.rm = TRUE, names = FALSE),
    p95          = stats::quantile(s, .95, na.rm = TRUE, names = FALSE),
    p99          = stats::quantile(s, .99, na.rm = TRUE, names = FALSE),
    peak_threads = if (all(is.na(dt$threads))) NA_real_ else max(dt$threads, na.rm = TRUE)
  )
}

# Per-label aggregate. Times in SECONDS. Sorted A-Z by Label; Error% last.
jm_by_label <- function(dt) {
  dt[, .(
    `Transaction Count` = .N,
    Min     = round(min(elapsed, na.rm = TRUE) / 1000, 2),
    Average = round(mean(elapsed, na.rm = TRUE) / 1000, 2),
    p80     = round(stats::quantile(elapsed, .80, na.rm = TRUE, names = FALSE) / 1000, 2),
    p90     = round(stats::quantile(elapsed, .90, na.rm = TRUE, names = FALSE) / 1000, 2),
    p95     = round(stats::quantile(elapsed, .95, na.rm = TRUE, names = FALSE) / 1000, 2),
    Max     = round(max(elapsed, na.rm = TRUE) / 1000, 2),
    `Error%` = round(100 * sum(!ok) / .N, 2)
  ), by = .(Transaction = label)][order(Transaction)]
}

# Time-bucketed series. One row per bucket -> tiny, fast to plot.
jm_timeseries <- function(dt, bucket_s = 60) {
  tz <- attr(dt$ts, "tzone")
  b  <- floor(as.numeric(dt$ts) / bucket_s) * bucket_s
  d  <- data.table::data.table(
    bucket  = as.POSIXct(b, origin = "1970-01-01", tz = tz),
    elapsed = dt$elapsed, ok = dt$ok, threads = dt$threads
  )
  d[, .(
    count      = .N,
    throughput = .N / bucket_s,
    errors     = sum(!ok),
    error_rate = round(100 * sum(!ok) / .N, 2),
    mean       = round(mean(elapsed, na.rm = TRUE) / 1000, 3),
    p80        = round(stats::quantile(elapsed, .80, na.rm = TRUE, names = FALSE) / 1000, 3),
    p90        = round(stats::quantile(elapsed, .90, na.rm = TRUE, names = FALSE) / 1000, 3),
    p95        = round(stats::quantile(elapsed, .95, na.rm = TRUE, names = FALSE) / 1000, 3),
    threads    = if (all(is.na(threads))) NA_real_ else max(threads, na.rm = TRUE)
  ), by = bucket][order(bucket)]
}

# Pre-binned histogram for the distribution chart (never pass raw to a plot).
# Bins are in SECONDS.
jm_hist <- function(dt, bins = 60) {
  x <- dt$elapsed[is.finite(dt$elapsed)] / 1000
  if (!length(x)) return(data.table::data.table(mid = numeric(), count = integer()))
  br <- seq(min(x), max(x), length.out = bins + 1)
  if (length(unique(br)) < 2) br <- c(x[1] - 1, x[1] + 1)
  h <- graphics::hist(x, breaks = br, plot = FALSE)
  data.table::data.table(mid = h$mids, count = h$counts)
}

# Largest-Triangle-Three-Buckets downsampling: keep the visual shape of a
# huge series using only ~`threshold` points. Returns indices to keep.
jm_lttb <- function(x, y, threshold = 2000) {
  n <- length(x)
  if (threshold >= n || threshold < 3) return(seq_len(n))
  x <- as.numeric(x); y <- as.numeric(y)
  out <- integer(threshold); out[1] <- 1L; a <- 1L
  bs <- (n - 2) / (threshold - 2)
  for (i in seq_len(threshold - 2)) {
    as_ <- min(floor(i * bs) + 2L, n); ae <- min(floor((i + 1) * bs) + 2L, n)
    avg_x <- mean(x[as_:ae]); avg_y <- mean(y[as_:ae])
    rs <- min(floor((i - 1) * bs) + 2L, n); re <- min(floor(i * bs) + 1L, n)
    idx <- rs:re
    area <- abs((x[a] - avg_x) * (y[idx] - y[a]) - (x[a] - x[idx]) * (avg_y - y[a]))
    chosen <- idx[which.max(area)]
    out[i + 1L] <- chosen; a <- chosen
  }
  out[threshold] <- n
  out
}

# Resolve per-label SLA targets (seconds). overrides is an optional data.table
# with columns Label, p80, p95; missing labels/values fall back to the globals.
jm_sla_target <- function(label, p80_g, p95_g, overrides = NULL) {
  p80 <- rep(p80_g, length(label)); p95 <- rep(p95_g, length(label))
  if (!is.null(overrides) && nrow(overrides)) {
    m <- match(label, overrides$Label)
    hit <- !is.na(m)
    o80 <- overrides$p80[m]; o95 <- overrides$p95[m]
    p80[hit & !is.na(o80)] <- o80[hit & !is.na(o80)]
    p95[hit & !is.na(o95)] <- o95[hit & !is.na(o95)]
  }
  list(p80 = p80, p95 = p95)
}

# Overall verdict for a run: the 80th and 95th percentile each compared to its
# own SLA target. Overall is "pass" (both), "partial" (one), or "fail" (neither).
jm_verdict <- function(s, p80_target = 2.1, p95_target = 3.6) {
  p80 <- !is.na(s$p80) && s$p80 <= p80_target
  p95 <- !is.na(s$p95) && s$p95 <= p95_target
  list(p80_pass = p80, p95_pass = p95,
       overall  = if (p80 && p95) "pass" else if (!p80 && !p95) "fail" else "partial")
}

# NZ date formatting: 14 -> "14th", and a date -> "14th Nov 2023".
nz_ordinal <- function(day) {
  day <- as.integer(day)
  sfx <- if (day %% 100 %in% 11:13) "th"
         else switch(as.character(day %% 10), "1" = "st", "2" = "nd", "3" = "rd", "th")
  paste0(day, sfx)
}
fmt_date_nz <- function(d) {
  d <- as.Date(d)
  if (is.na(d)) return(NA_character_)
  paste0(nz_ordinal(format(d, "%d")), " ", format(d, "%b %Y"))
}

# Overall sample-level compliance against the two targets (seconds).
jm_sla_compliance <- function(dt, p80_target = 2.1, p95_target = 3.6) {
  s <- dt$elapsed / 1000
  n <- length(s)
  if (!n) return(list(within_p80 = NA_real_, within_p95 = NA_real_, over_p95 = NA_real_))
  list(within_p80 = 100 * mean(s <= p80_target, na.rm = TRUE),
       within_p95 = 100 * mean(s <= p95_target, na.rm = TRUE),
       over_p95   = 100 * mean(s >  p95_target, na.rm = TRUE))
}

# Per-label SLA pass/fail: each label's 80th and 95th percentile vs its target
# (targets may be overridden per transaction). Times in seconds.
jm_sla_by_label <- function(dt, p80_g = 2.1, p95_g = 3.6, overrides = NULL) {
  bl <- jm_by_label(dt)
  tg <- jm_sla_target(bl$Transaction, p80_g, p95_g, overrides)
  pf <- function(val, target) ifelse(is.na(val), "-", ifelse(val <= target, "Pass", "Fail"))
  data.table::data.table(
    Transaction  = bl$Transaction,
    p80          = bl$p80, `80th SLA` = round(tg$p80, 2), `80th` = pf(bl$p80, tg$p80),
    p95          = bl$p95, `95th SLA` = round(tg$p95, 2), `95th` = pf(bl$p95, tg$p95))
}

# Pretty filename -> project / run id / date (carried over from the old app).
jm_file_meta <- function(name) {
  stem  <- tools::file_path_sans_ext(name)
  parts <- strsplit(stem, "_")[[1]]
  run   <- if (length(parts) >= 2) paste(tail(parts, 2), collapse = "_") else stem
  proj  <- if (length(parts) >= 3) paste(head(parts, -2), collapse = " ") else stem
  date  <- tryCatch(fmt_date_nz(as.Date(substr(gsub("\\D", "", run), 1, 8), "%Y%m%d")),
                    error = function(e) NA_character_)
  list(project = proj, run = run, date = date)
}
# =====================================================================
# Comparison table builders (shared by the app and the HTML export)
# ---------------------------------------------------------------------
# Each takes `files`: a list of list(tag = <short id>, bl = jm_by_label(),
# sla = jm_sla_by_label()). They return a display-ready data.frame with
# HTML two-line column headers, the column names that begin each file
# group (for drawing separators), and a "not comparable" table for labels
# that appear in only one test.
# =====================================================================

.cmp_fmt_s <- function(x) ifelse(is.na(x), "-", paste0(formatC(x, format = "f", digits = 2), " s"))
.cmp_fmt_p <- function(x) ifelse(is.na(x), "-", sprintf("%.2f%%", x))
.cmp_delta_html <- function(d, unit) {
  col <- ifelse(is.na(d) | abs(d) < 0.005, "#6c757d", ifelse(d < 0, "#2e7d32", "#c62828"))
  ifelse(is.na(d), "-", sprintf('<span style="color:%s">%+.2f%s</span>', col, d, unit))
}
.cmp_hdr <- function(tag, sub) sprintf("%s<br><span class='cmp-sub'>%s</span>", tag, sub)

# labels present in >= 2 of the files can be compared; the rest are "single".
.cmp_split <- function(files, getter) {
  cnt <- table(unlist(lapply(files, function(f) getter(f)$Transaction)))
  list(comparable = sort(names(cnt)[cnt >= 2]),
       single     = sort(names(cnt)[cnt == 1]))
}
.cmp_only_in <- function(files, labels, getter) {
  vapply(labels, function(l)
    paste(stats::na.omit(vapply(files, function(f)
      if (l %in% getter(f)$Transaction) f$tag else NA_character_, character(1))), collapse = ", "),
    character(1))
}
.cmp_missing_from <- function(files, labels, getter) {
  vapply(labels, function(l)
    paste(stats::na.omit(vapply(files, function(f)
      if (l %in% getter(f)$Transaction) NA_character_ else f$tag, character(1))), collapse = ", "),
    character(1))
}

# Add a metric group (all files' values for one metric, side by side) to a
# building table. Records the first column name so a divider can be drawn.
.cmp_add_group <- function(state, files, key, sub, fmt, valfun) {
  first <- TRUE
  for (f in files) {
    nm <- paste0(f$tag, "::", key)
    state$df[[nm]] <- fmt(valfun(f))
    if (first) { state$starts <- c(state$starts, nm); first <- FALSE }
    state$cn <- c(state$cn, .cmp_hdr(f$tag, sub))
  }
  state
}

# Per-label response-time comparison.
# Returns: values (grouped by metric), diff (deltas vs baseline, by metric),
# and single (labels present in only one test).
jm_compare_table <- function(files) {
  g  <- function(f) f$bl
  sp <- .cmp_split(files, g)
  comparable <- sp$comparable
  # aligned per-file rows for the comparable labels
  af <- lapply(files, function(f)
    list(tag = f$tag, row = f$bl[match(comparable, f$bl$Transaction)]))
  base <- af[[1]]$row

  # ---- VALUES, grouped by metric ----
  v <- list(df = data.frame(Transaction = comparable, check.names = FALSE, stringsAsFactors = FALSE),
            cn = "Transaction", starts = character(0))
  v <- .cmp_add_group(v, af, "p80", "80th Percentile", .cmp_fmt_s, function(f) f$row$p80)
  v <- .cmp_add_group(v, af, "p95", "95th Percentile", .cmp_fmt_s, function(f) f$row$p95)
  v <- .cmp_add_group(v, af, "err", "Error %",         .cmp_fmt_p, function(f) f$row$`Error%`)
  mf <- .cmp_missing_from(files, comparable, g)
  v$df[["Missing from"]] <- ifelse(nzchar(mf), mf, "-"); v$cn <- c(v$cn, "Missing from")

  # ---- DIFFERENCES vs baseline (files 2..n), grouped by metric ----
  d <- list(df = data.frame(Transaction = comparable, check.names = FALSE, stringsAsFactors = FALSE),
            cn = "Transaction", starts = character(0))
  others <- if (length(af) >= 2) af[-1] else list()
  if (length(others)) {
    d <- .cmp_add_group(d, others, "dp80", "80th Pctl &Delta;",
                        function(x) .cmp_delta_html(x, " s"), function(f) f$row$p80 - base$p80)
    d <- .cmp_add_group(d, others, "dp95", "95th Pctl &Delta;",
                        function(x) .cmp_delta_html(x, " s"), function(f) f$row$p95 - base$p95)
    d <- .cmp_add_group(d, others, "derr", "Error % &Delta;",
                        function(x) .cmp_delta_html(x, "%"), function(f) f$row$`Error%` - base$`Error%`)
  }

  single <- if (length(sp$single))
    data.frame(Transaction = sp$single, `Only in` = .cmp_only_in(files, sp$single, g),
               check.names = FALSE) else data.frame()

  list(values = list(df = v$df, colnames = v$cn, group_starts = v$starts),
       diff   = list(df = d$df, colnames = d$cn, group_starts = d$starts),
       single = single)
}

# Per-label SLA pass/fail comparison, showing the margin in seconds (grouped by metric).
jm_sla_compare_table <- function(files, p80_g = 2.1, p95_g = 3.6) {
  g  <- function(f) f$sla
  sp <- .cmp_split(files, g)
  comparable <- sp$comparable
  af <- lapply(files, function(f)
    list(tag = f$tag, row = f$sla[match(comparable, f$sla$Transaction)]))

  # margin = value - target. <= 0 passed (by abs), > 0 failed (by margin).
  margin_html <- function(m) ifelse(is.na(m), "-",
    ifelse(m <= 0,
      sprintf("<span style='color:#16A34A;font-weight:600'>Pass by %.2fs</span>", abs(m)),
      sprintf("<span style='color:#E5484D;font-weight:600'>Fail by %.2fs</span>", m)))
  v <- list(df = data.frame(Transaction = comparable, check.names = FALSE, stringsAsFactors = FALSE),
            cn = "Transaction", starts = character(0))
  v <- .cmp_add_group(v, af, "r80", "80th vs SLA", margin_html,
                      function(f) f$row$p80 - f$row$`80th SLA`)
  v <- .cmp_add_group(v, af, "r95", "95th vs SLA", margin_html,
                      function(f) f$row$p95 - f$row$`95th SLA`)
  mf <- .cmp_missing_from(files, comparable, g)
  v$df[["Missing from"]] <- ifelse(nzchar(mf), mf, "-"); v$cn <- c(v$cn, "Missing from")

  single <- if (length(sp$single))
    data.frame(Transaction = sp$single, `Only in` = .cmp_only_in(files, sp$single, g),
               check.names = FALSE) else data.frame()
  list(values = list(df = v$df, colnames = v$cn, group_starts = v$starts), single = single)
}
