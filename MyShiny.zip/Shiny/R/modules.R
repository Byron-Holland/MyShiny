# =====================================================================
# R/modules.R  -  shared helpers + the five tab modules
# =====================================================================

`%||%` <- function(a, b) {
  if (is.null(a) || length(a) == 0 || (length(a) == 1 && is.na(a))) b else a
}

# ---- small formatters -----------------------------------------------
fmt_ms  <- function(x) if (is.na(x)) "-" else paste0(format(round(x), big.mark = ","), " ms")
fmt_s   <- function(x) if (is.na(x)) "-" else paste0(formatC(x, format = "f", digits = 2, big.mark = ","), " s")
fmt_int <- function(x) if (is.na(x)) "-" else format(round(x), big.mark = ",")
fmt_pct <- function(x) if (is.na(x)) "-" else sprintf("%.2f%%", x)
fmt_num <- function(x, d = 2) if (is.na(x)) "-" else formatC(x, format = "f", digits = d, big.mark = ",")

# Map an SLA band to a bslib theme colour.
band_theme <- function(band) c(green = "success", orange = "warning",
                               red = "danger", na = "secondary")[[band]]

# x-axis range padded by `pad_s` seconds, as strings plotly accepts.
pad_range <- function(ts_vec, pad_s) {
  if (!length(ts_vec)) return(NULL)
  fmt <- function(t) format(t, "%Y-%m-%d %H:%M:%S")
  list(fmt(min(ts_vec) - pad_s), fmt(max(ts_vec) + pad_s))
}

# shared ggplot look (used by static charts and the HTML export)
gg_base <- function() {
  theme_minimal(base_size = 13) +
    theme(panel.grid.minor = element_blank(),
          plot.title = element_text(face = "bold"))
}

# ---- plotly theming + SLA reference lines ---------------------------
ply_hline <- function(y, color) list(
  type = "line", xref = "paper", x0 = 0, x1 = 1, yref = "y", y0 = y, y1 = y,
  line = list(color = color, width = 1, dash = "dot"), opacity = 0.6, layer = "below")

ply_axis <- function(title = "", range = NULL, dark = FALSE) {
  grid <- if (dark) "rgba(255,255,255,0.12)" else "rgba(0,0,0,0.10)"
  list(title = title, range = range, gridcolor = grid, zerolinecolor = grid)
}
ply_skin <- function(p, dark) {
  fg <- if (dark) "#e9ecef" else "#212529"
  hb <- if (dark) "#2b3035" else "#ffffff"
  layout(p, paper_bgcolor = "rgba(0,0,0,0)", plot_bgcolor = "rgba(0,0,0,0)",
         font = list(color = fg), legend = list(font = list(color = fg)),
         hoverlabel = list(bgcolor = hb, bordercolor = fg, font = list(color = fg)))
}

# ---- interactive (plotly) charts: only ever fed AGGREGATED data -----
ply_rt <- function(ts, pad = NULL, p80_target = 2.1, p95_target = 3.0, dark = FALSE) {
  plot_ly(ts, x = ~bucket) |>
    add_lines(y = ~mean, name = "Average", line = list(color = ACCENT)) |>
    add_lines(y = ~p80, name = "p80", line = list(color = "#FB8C00")) |>
    add_lines(y = ~p95, name = "p95", line = list(color = "#E53935")) |>
    layout(yaxis = ply_axis("Response time (seconds)", NULL, dark),
           xaxis = ply_axis("", pad, dark), hovermode = "x unified",
           shapes = list(ply_hline(p80_target, "#FB8C00"), ply_hline(p95_target, "#E53935")),
           annotations = list(
             list(x = 0, xref = "paper", y = p80_target, yref = "y", xanchor = "left",
                  yshift = 8, showarrow = FALSE, text = paste0("80th SLA ", p80_target, "s"),
                  font = list(size = 10, color = "#FB8C00")),
             list(x = 0, xref = "paper", y = p95_target, yref = "y", xanchor = "left",
                  yshift = 8, showarrow = FALSE, text = paste0("95th SLA ", p95_target, "s"),
                  font = list(size = 10, color = "#E53935")))) |>
    ply_skin(dark)
}
ply_line <- function(ts, y, title, color = ACCENT, pad = NULL, dark = FALSE) {
  plot_ly(ts, x = ~bucket, y = as.formula(paste0("~", y)),
          type = "scatter", mode = "lines", line = list(color = color)) |>
    layout(yaxis = ply_axis(title, NULL, dark), xaxis = ply_axis("", pad, dark)) |>
    ply_skin(dark)
}

# ---- static (ggplot) charts: thematic auto-handles light/dark -------
gg_rt <- function(ts) {
  ggplot(ts, aes(bucket)) +
    geom_line(aes(y = mean, colour = "Average")) +
    geom_line(aes(y = p80,  colour = "p80")) +
    geom_line(aes(y = p95,  colour = "p95")) +
    scale_colour_manual(values = c(Average = ACCENT, p80 = "#FB8C00", p95 = "#E53935")) +
    labs(x = NULL, y = "Response time (seconds)", colour = NULL) + gg_base()
}
gg_throughput <- function(ts) ggplot(ts, aes(bucket, throughput)) +
  geom_line(colour = ACCENT) + labs(x = NULL, y = "Requests / sec") + gg_base()
gg_hist <- function(h) ggplot(h, aes(mid, count)) +
  geom_col(fill = ACCENT, width = diff(range(h$mid)) / max(1, nrow(h))) +
  labs(x = "Response time (seconds)", y = "Count") + gg_base()

# Shared metrics pipeline. All reactives here are session-cached, so a
# tab switch never recomputes; they invalidate only when inputs change.
make_pipe <- function(dt_r, settings) {
  filtered <- reactive({
    dt <- dt_r(); req(dt)
    jm_filter(dt, settings()$exclude, settings()$rampup)
  })
  list(
    filtered = filtered,
    summary  = reactive(jm_summary(filtered())),
    by_label = reactive(jm_by_label(filtered())),
    ts       = reactive(jm_timeseries(filtered(), settings()$bucket))
  )
}

# Reusable server-side DT (browser only ever receives the current page).
dt_table <- function(df, order = NULL, buttons = TRUE) {
  dom  <- if (buttons) "Blfrtip" else "lfrtip"
  opts <- list(pageLength = 10, scrollX = TRUE, dom = dom,
               lengthMenu = list(c(10, 25, 50, 100, -1),
                                 c("10", "25", "50", "100", "All")))
  ext  <- character(0)
  if (buttons) { opts$buttons <- c("colvis", "csv"); ext <- "Buttons" }
  if (!is.null(order)) opts$order <- order
  DT::datatable(df, rownames = FALSE, filter = "top", selection = "none",
                extensions = ext, style = "bootstrap5", options = opts)
}

# Short explanatory caption shown at the top of a section / tab.
intro <- function(text) div(class = "section-intro text-muted small mb-2", text)

# Render a built comparison table: HTML two-line headers, column visibility,
# per-file group separators. Re-rendered whenever the file set changes, so
# colvis always reflects the current columns (incl. newly added files).
cmp_datatable <- function(built, page = 15) {
  dt <- DT::datatable(
    built$df, colnames = built$colnames, rownames = FALSE, selection = "none",
    escape = FALSE, filter = "top", extensions = "Buttons", style = "bootstrap5",
    options = list(pageLength = page, scrollX = TRUE, dom = "Blfrtip",
                   buttons = c("colvis", "csv")))
  if (length(built$group_starts))
    dt <- DT::formatStyle(dt, built$group_starts, `border-left` = "2px solid #9aa0a6")
  dt
}

# A file picker that auto-refreshes from the shared store.
file_picker <- function(ns, multiple = FALSE)
  selectInput(ns("file"), "Data file", choices = NULL, multiple = multiple, width = "100%")

refresh_picker <- function(session, rv, input, multiple = FALSE) {
  observe({
    ch <- names(rv$data)
    cur <- isolate(input$file)
    sel <- if (multiple) (cur %||% utils::head(ch, 2)) else (cur %||% ch[1])
    updateSelectInput(session, "file", choices = ch, selected = sel)
  })
}

# =====================================================================
# CONFIG
# =====================================================================
config_ui <- function(id) {
  ns <- NS(id)
  layout_columns(
    col_widths = c(7, 5, 12, 12),
    card(card_header("Load results"),
         fileInput(ns("files"), "Upload JMeter CSV file(s)", multiple = TRUE,
                   accept = ".csv", width = "100%"),
         actionButton(ns("sample"), "Load sample data", icon = icon("flask"),
                      class = "btn-outline-primary btn-sm"),
         hr(), strong("Loaded files"), uiOutput(ns("loaded")),
         selectInput(ns("remove_pick"), NULL, choices = NULL, width = "100%"),
         div(actionButton(ns("remove"), "Remove", class = "btn-outline-danger btn-sm"),
             actionButton(ns("clear"), "Clear all", class = "btn-outline-secondary btn-sm"))),
    card(card_header("Settings"),
         selectInput(ns("tz"), "Timezone",
                     choices = c("Pacific/Auckland", "Australia/Brisbane", "UTC"),
                     selected = "Pacific/Auckland"),
         layout_columns(
           numericInput(ns("bucket"), "Time bucket (sec)", 60, min = 1, step = 1),
           numericInput(ns("pad"), "Axis padding (min)", 0.1, min = 0, step = 0.1)),
         layout_columns(
           numericInput(ns("sla_p80"), "80th percentile SLA (s)", 2.1, min = 0, step = 0.1),
           numericInput(ns("sla_p95"), "95th percentile SLA (s)", 3.0, min = 0, step = 0.1)),
         helpText("Two targets: the 80th and 95th percentile each have their own SLA."),
         tags$hr(),
         tags$strong("Override SLAs per transaction"),
         p(class = "text-muted small",
           "Optional CSV to set per-transaction targets. Columns: Transaction, 80pct, 95pct. Any transaction not listed uses the targets above."),
         fileInput(ns("sla_override"), NULL, accept = c(".csv", "text/csv"), buttonLabel = "Choose CSV"),
         div(class = "d-flex align-items-center gap-2 mb-2",
             actionButton(ns("sla_override_clear"), "Clear overrides", class = "btn-sm btn-outline-secondary"),
             span(class = "text-muted small", textOutput(ns("sla_override_count"), inline = TRUE))),
         DTOutput(ns("sla_override_tbl")),
         radioButtons(ns("render_mode"), "Heavy-plot rendering",
                      c("Static (fast)" = "static", "Interactive" = "interactive"),
                      selected = "static", inline = TRUE),
         textInput(ns("exclude"), "Exclude labels (regex)",
                   value = "^Debug|^calculate|^_GetBe|^txn_|^Txn_|^JDBC|^JSR223"),
         numericInput(ns("rampup"), "Trim ramp-up (min)", 0, min = 0, step = 1)),
    card(card_header("Export shareable report"), full_screen = FALSE,
         p(class = "text-muted",
           "Builds one self-contained HTML file (opens offline). Static tables and charts."),
         checkboxGroupInput(ns("export_files"), "Include files", choices = NULL),
         downloadButton(ns("export"), "Export HTML report", class = "btn-primary")),
    card(card_header("Manual column mapping"),
         p(class = "text-muted small",
           "For files with no header row or an unusual layout. Pick which column holds each field, using the preview to guide you."),
         uiOutput(ns("map_ui")))
  )
}

config_server <- function(id, rv) moduleServer(id, function(input, output, session) {
  ns <- session$ns
  sla_ov <- reactiveVal(NULL)   # per-transaction overrides: Label, p80, p95

  observeEvent(input$sla_override, {
    f <- input$sla_override
    df <- tryCatch(data.table::fread(f$datapath), error = function(e) NULL)
    if (is.null(df) || !nrow(df)) {
      showNotification("Could not read that CSV.", type = "error"); return() }
    nm <- tolower(gsub("[^a-z0-9]", "", names(df)))
    li <- which(nm %in% c("transaction", "label", "samplelabel", "sampler", "name"))[1]
    i80 <- which(grepl("80", nm))[1]; i95 <- which(grepl("95", nm))[1]
    if (is.na(li) || is.na(i80) || is.na(i95)) {
      showNotification("Expected columns: Transaction, 80pct, 95pct.", type = "error"); return() }
    ov <- data.table::data.table(
      Label = as.character(df[[li]]),
      p80   = suppressWarnings(as.numeric(df[[i80]])),
      p95   = suppressWarnings(as.numeric(df[[i95]])))
    ov <- ov[!is.na(Label) & Label != ""]
    sla_ov(ov)
    showNotification(sprintf("Loaded %d SLA override(s).", nrow(ov)), type = "message")
  })
  observeEvent(input$sla_override_clear, {
    sla_ov(NULL)
  })
  output$sla_override_count <- renderText({
    ov <- sla_ov(); if (is.null(ov)) "No overrides loaded." else sprintf("%d transaction(s) overridden.", nrow(ov)) })
  output$sla_override_tbl <- renderDT({
    ov <- sla_ov(); req(!is.null(ov) && nrow(ov) > 0)
    disp <- data.frame(Transaction = ov$Label,
                       `80th SLA (s)` = ov$p80, `95th SLA (s)` = ov$p95, check.names = FALSE)
    DT::datatable(disp, rownames = FALSE, selection = "none",
                  options = list(pageLength = 5, dom = "tp", scrollX = TRUE))
  }, server = FALSE)

  settings <- reactive(list(
    tz            = input$tz %||% "Pacific/Auckland",
    bucket        = max(1, input$bucket %||% 60),
    pad_s         = (input$pad %||% 0.1) * 60,
    sla_p80       = input$sla_p80 %||% 2.1,
    sla_p95       = input$sla_p95 %||% 3.0,
    sla_overrides = sla_ov(),
    render_mode   = input$render_mode %||% "static",
    exclude       = input$exclude %||% "",
    rampup        = input$rampup %||% 0
  ))

  ingest <- function(paths, names) {
    withProgress(message = "Reading files", value = 0, {
      n <- length(paths)
      for (i in seq_len(n)) {
        incProgress(1 / n, detail = names[i])
        res <- tryCatch(jm_ingest(paths[i], names[i], tz = isolate(input$tz) %||% "Pacific/Auckland"),
                        error = function(e) e)
        if (inherits(res, "error")) {
          pend <- rv$pending; pend[[names[i]]] <- paths[i]; rv$pending <- pend
          showNotification(
            paste0(names[i], " has no recognisable header. Use the Manual column mapping panel below."),
            type = "warning", duration = NULL)
          next
        }
        rv$data[[names[i]]] <- list(name = names[i], dt = res,
                                    meta = jm_file_meta(names[i]), summary = jm_summary(res))
      }
    })
  }

  observeEvent(input$files,  { req(input$files);  ingest(input$files$datapath, input$files$name) })
  observeEvent(input$sample, { p <- write_sample_csv(); ingest(p, basename(p)) })

  observe(updateCheckboxGroupInput(session, "export_files",
                                   choices = names(rv$data), selected = names(rv$data)))
  observe(updateSelectInput(session, "remove_pick", choices = names(rv$data)))

  # --- remove / clear loaded files ---
  observeEvent(input$remove, {
    req(input$remove_pick)
    d <- rv$data; d[[input$remove_pick]] <- NULL; rv$data <- d
  })
  observeEvent(input$clear, { rv$data <- list() })

  # --- manual column mapping (headerless / unusual files) ---
  output$map_ui <- renderUI({
    if (!length(rv$pending)) return(em("No files need mapping."))
    tagList(
      selectInput(ns("map_file"), "File to map", choices = names(rv$pending), width = "100%"),
      layout_columns(
        selectInput(ns("map_sep"), "Separator",
                    choices = c("Auto" = "auto", "Comma (,)" = ",",
                                "Semicolon (;)" = ";", "Tab" = "\t"), selected = "auto"),
        checkboxInput(ns("map_header"), "First row is a header (skip it)", FALSE)),
      div(style = "overflow-x:auto", tableOutput(ns("map_preview"))),
      layout_columns(
        selectInput(ns("map_time"),    "Timestamp *",          choices = NULL),
        selectInput(ns("map_elapsed"), "Response time (ms) *", choices = NULL),
        selectInput(ns("map_label"),   "Label *",              choices = NULL)),
      layout_columns(
        selectInput(ns("map_success"), "Success (optional)",       choices = NULL),
        selectInput(ns("map_code"),    "Response code (optional)", choices = NULL),
        selectInput(ns("map_message"), "Message (optional)",       choices = NULL),
        selectInput(ns("map_threads"), "Active users (optional)",  choices = NULL)),
      actionButton(ns("map_apply"), "Apply mapping & load", class = "btn-primary")
    )
  })

  map_pre <- reactive({
    req(input$map_file)
    p <- rv$pending[[input$map_file]]
    req(p)                                   # stop quietly if the file was just mapped/removed
    jm_preview(p, sep = input$map_sep %||% "auto")
  })

  output$map_preview <- renderTable({
    p <- map_pre(); req(p)
    as.data.frame(lapply(utils::head(p, 6), as.character), stringsAsFactors = FALSE)
  }, rownames = FALSE, striped = TRUE, bordered = TRUE, spacing = "xs")

  observe({
    p <- map_pre(); req(p)
    cols <- names(p)
    opt  <- c("(none)" = "", stats::setNames(cols, cols))
    updateSelectInput(session, "map_time",    choices = cols)
    updateSelectInput(session, "map_elapsed", choices = cols)
    updateSelectInput(session, "map_label",   choices = cols)
    for (f in c("map_success", "map_code", "map_message", "map_threads"))
      updateSelectInput(session, f, choices = opt)
  })

  observeEvent(input$map_apply, {
    req(input$map_file)
    mapping <- list(time = input$map_time, elapsed = input$map_elapsed, label = input$map_label,
                    success = input$map_success, code = input$map_code,
                    message = input$map_message, threads = input$map_threads)
    res <- tryCatch(
      jm_ingest_mapped(rv$pending[[input$map_file]], input$map_file, mapping,
                       has_header = isTRUE(input$map_header),
                       sep = input$map_sep %||% "auto",
                       tz = isolate(input$tz) %||% "Pacific/Auckland"),
      error = function(e) e)
    if (inherits(res, "error")) {
      showNotification(conditionMessage(res), type = "error", duration = NULL); return()
    }
    nm <- input$map_file
    d <- rv$data
    d[[nm]] <- list(name = nm, dt = res, meta = jm_file_meta(nm), summary = jm_summary(res))
    rv$data <- d
    p <- rv$pending; p[[nm]] <- NULL; rv$pending <- p
    showNotification(paste("Loaded", nm), type = "message")
  })

  output$loaded <- renderUI({
    if (!length(rv$data)) return(em("No files loaded yet."))
    tags$ul(lapply(names(rv$data), function(nm) {
      s <- rv$data[[nm]]$summary
      tags$li(strong(nm), sprintf(" - %.1f min", s$duration_min))
    }))
  })

  output$export <- downloadHandler(
    filename = function() sprintf("jmeter-report-%s.html", format(Sys.time(), "%Y%m%d-%H%M")),
    content  = function(file) {
      req(length(input$export_files) > 0)
      withProgress(message = "Building report", value = 0.3, {
        st <- settings()
        arts <- lapply(input$export_files, function(nm) {
          d <- jm_filter(rv$data[[nm]]$dt, st$exclude, st$rampup)
          list(name = nm, meta = rv$data[[nm]]$meta, summary = jm_summary(d),
               by_label = jm_by_label(d), ts = jm_timeseries(d, st$bucket), hist = jm_hist(d),
               sla = jm_sla_by_label(d, st$sla_p80, st$sla_p95, st$sla_overrides),
               comp = jm_sla_compliance(d, st$sla_p80, st$sla_p95))
        })
        tmp <- file.path(tempdir(), "report.Rmd")
        file.copy("report.Rmd", tmp, overwrite = TRUE)
        incProgress(0.4)
        # thematic's showtext hook errors during static rmarkdown rendering, so
        # turn it off for the render and restore the app's auto-theming after.
        thematic::thematic_off()
        on.exit(thematic::thematic_shiny(font = "auto"), add = TRUE)
        rmarkdown::render(tmp, output_file = file,
                          params = list(arts = arts, settings = st),
                          envir = new.env(parent = globalenv()), quiet = TRUE)
      })
    }
  )

  settings
})

# =====================================================================
# EXEC SUMMARY
# =====================================================================
execsummary_ui <- function(id) {
  ns <- NS(id)
  tagList(
    file_picker(ns),
    intro("A one-glance executive view of the selected run: the overall verdict against your SLAs, the headline numbers, and a plain-English summary for stakeholders."),
    uiOutput(ns("verdict")),
    uiOutput(ns("kpis")),
    layout_columns(
      col_widths = c(6, 6),
      card(card_header("Summary"), uiOutput(ns("narrative"))),
      tagList(
        card(card_header("Top 5 fastest transactions (80th percentile)"), DTOutput(ns("fast"))),
        card(card_header("Top 5 slowest transactions (80th percentile)"), DTOutput(ns("slow")))
      )
    )
  )
}

execsummary_server <- function(id, rv, settings) moduleServer(id, function(input, output, session) {
  refresh_picker(session, rv, input)
  chosen  <- reactive({ req(input$file, input$file %in% names(rv$data)); rv$data[[input$file]]$dt })
  pipe    <- make_pipe(chosen, settings)
  comp    <- reactive(jm_sla_compliance(pipe$filtered(), settings()$sla_p80, settings()$sla_p95))
  sla_lbl <- reactive(jm_sla_by_label(pipe$filtered(), settings()$sla_p80,
                                      settings()$sla_p95, settings()$sla_overrides))
  verdict <- reactive(jm_verdict(pipe$summary(), settings()$sla_p80, settings()$sla_p95))

  output$verdict <- renderUI({
    v <- verdict(); s <- pipe$summary(); st <- settings()
    pv <- function(title, pass, val, target) value_box(
      title, if (pass) "PASS" else "FAIL",
      p(sprintf("%s vs %ss SLA", fmt_s(val), target)),
      showcase = bs_icon(if (pass) "check-circle" else "x-circle"),
      theme = if (pass) "success" else "danger")
    ov <- switch(v$overall,
      pass    = list("PASS",    "success", "check-circle-fill",      "Both percentiles within their SLA"),
      partial = list("PARTIAL", "warning", "exclamation-circle-fill", "One percentile within SLA, one over"),
      fail    = list("FAIL",    "danger",  "x-circle-fill",          "Both percentiles over their SLA"))
    layout_columns(
      col_widths = c(4, 4, 4), fill = FALSE,
      value_box("Overall verdict", ov[[1]], p(ov[[4]]),
        showcase = bs_icon(ov[[3]]), theme = ov[[2]]),
      pv("80th percentile", v$p80_pass, s$p80, st$sla_p80),
      pv("95th percentile", v$p95_pass, s$p95, st$sla_p95))
  })

  output$kpis <- renderUI({
    s <- pipe$summary(); sl <- sla_lbl()
    n <- nrow(sl); p80n <- sum(sl$`80th` == "Pass"); p95n <- sum(sl$`95th` == "Pass")
    vb <- function(t, v, i, sub = NULL) value_box(t, v, if (!is.null(sub)) p(class = "small mb-0", sub),
                                                  showcase = bs_icon(i))
    layout_columns(
      col_widths = c(3, 3, 3, 3), fill = FALSE,
      vb("Transactions", fmt_int(s$samples), "stack"),
      vb("Error rate", fmt_pct(s$error_pct), "exclamation-triangle"),
      vb("Passed 80th SLA", sprintf("%d / %d", p80n, n), "check-circle", "transactions"),
      vb("Passed 95th SLA", sprintf("%d / %d", p95n, n), "check-circle", "transactions"))
  })

  output$narrative <- renderUI({
    s <- pipe$summary(); st <- settings(); v <- verdict(); sl <- sla_lbl()
    slow <- pipe$by_label()[order(-p80)][1]
    meta <- rv$data[[input$file]]$meta
    failed <- round(s$samples * s$error_pct / 100)
    n <- nrow(sl); p80n <- sum(sl$`80th` == "Pass"); p95n <- sum(sl$`95th` == "Pass")
    head <- switch(v$overall,
      pass    = "This run met both SLAs: the 80th and 95th percentile response times were within their targets.",
      partial = "This run partially met the SLAs: one percentile was within target and one was over.",
      fail    = "This run did not meet the SLAs: both the 80th and 95th percentile response times were over their targets.")
    wo <- function(ok) if (ok) "within" else "over"
    tags$div(
      tags$p(class = "lead", head),
      tags$p(tags$strong("Test run. "), sprintf(
        "%s%s processed %s transactions over %.0f minutes at %.1f requests per second.",
        meta$run, if (!is.na(meta$date)) paste0(" on ", meta$date) else "",
        fmt_int(s$samples), s$duration_min, s$throughput)),
      tags$p(tags$strong("Response times. "), sprintf(
        "Average %s, 80th percentile %s, 95th percentile %s.",
        fmt_s(s$mean), fmt_s(s$p80), fmt_s(s$p95))),
      tags$p(tags$strong("Response time vs SLA. "), sprintf(
        "Overall, the 80th percentile (%s) is %s its %ss SLA and the 95th percentile (%s) is %s its %ss SLA. Across %d transactions, %d passed the 80th SLA and %d passed the 95th.",
        fmt_s(s$p80), wo(v$p80_pass), st$sla_p80, fmt_s(s$p95), wo(v$p95_pass), st$sla_p95,
        n, p80n, p95n)),
      tags$p(tags$strong("Errors. "), sprintf(
        "Error rate %s (%s failed transactions).", fmt_pct(s$error_pct), fmt_int(failed))),
      tags$p(tags$strong("Watch. "), sprintf(
        "Slowest transaction by 80th percentile was \"%s\" at %s.",
        slow$Label, fmt_s(slow$p80))))
  })

  top5 <- function(desc) {
    bl <- pipe$by_label()
    bl <- bl[order(if (desc) -bl$p80 else bl$p80)]
    utils::head(bl[, c("Label", "Transaction Count", "p80"), with = FALSE], 5)
  }
  output$fast <- renderDT(dt_table(top5(FALSE), buttons = FALSE), server = TRUE)
  output$slow <- renderDT(dt_table(top5(TRUE),  buttons = FALSE), server = TRUE)
})

# =====================================================================
# DASHBOARD
# =====================================================================
dashboard_ui <- function(id) {
  ns <- NS(id)
  tagList(
    file_picker(ns),
    intro("An at-a-glance summary of the selected test run: headline response-time, throughput and error metrics, with charts across the full duration of the test."),
    uiOutput(ns("kpis")),
    layout_columns(
      col_widths = c(7, 5),
      card(card_header("Response time over time"), full_screen = TRUE,
           plotlyOutput(ns("rt"), height = "320px")),
      card(card_header("Transactions"), full_screen = TRUE,
           DTOutput(ns("top")))
    ),
    layout_columns(
      card(card_header("Throughput"), full_screen = TRUE,
           plotlyOutput(ns("tp"), height = "300px")),
      card(card_header("Error rate"), full_screen = TRUE,
           plotlyOutput(ns("er"), height = "300px"))
    )
  )
}

dashboard_server <- function(id, rv, settings, dark) moduleServer(id, function(input, output, session) {
  refresh_picker(session, rv, input)
  chosen <- reactive({ req(input$file, input$file %in% names(rv$data)); rv$data[[input$file]]$dt })
  pipe   <- make_pipe(chosen, settings)

  output$kpis <- renderUI({
    s <- pipe$summary()
    vb <- function(title, value, icon)
      value_box(title, value, showcase = bs_icon(icon))   # generic look, not SLA-coloured
    layout_columns(
      col_widths = c(2, 2, 2, 2, 2, 2), fill = FALSE,
      vb("Transaction Count", fmt_int(s$samples), "stack"),
      vb("Errors", fmt_pct(s$error_pct), "exclamation-triangle"),
      vb("Throughput", paste0(fmt_num(s$throughput, 1), "/s"), "speedometer2"),
      vb("Average", fmt_s(s$mean), "graph-up"),
      vb("p80", fmt_s(s$p80), "graph-up"),
      vb("p95", fmt_s(s$p95), "graph-up-arrow")
    )
  })

  output$rt  <- renderPlotly(ply_rt(pipe$ts(), pad_range(pipe$ts()$bucket, settings()$pad_s),
                                     settings()$sla_p80, settings()$sla_p95, dark()))
  output$tp  <- renderPlotly(ply_line(pipe$ts(), "throughput", "Requests / sec",
                                       pad = pad_range(pipe$ts()$bucket, settings()$pad_s), dark = dark()))
  output$er  <- renderPlotly(ply_line(pipe$ts(), "error_rate", "Error rate (%)", color = "#E53935",
                                       pad = pad_range(pipe$ts()$bucket, settings()$pad_s), dark = dark()))
  output$top <- renderDT(dt_table(pipe$by_label(), order = list(list(0, "asc")), buttons = FALSE), server = TRUE)
})

# =====================================================================
# TABLES
# =====================================================================
tables_ui <- function(id) {
  ns <- NS(id)
  tagList(
    file_picker(ns),
    navset_card_tab(
      nav_panel("Response Time Table",
                intro("Response times for each transaction in the test, summarised as average, min, max and percentiles (in seconds), plus the error rate per transaction. Click a column header to sort."),
                div(style = "min-height:560px", DTOutput(ns("agg")))),
      nav_panel("Errors",
                intro("Every failed sample, grouped by transaction, response code and message, with counts."),
                div(style = "min-height:560px", DTOutput(ns("err")))),
      nav_panel("Raw samples",
                intro("Individual samples (most recent 50,000 for responsiveness) with timestamp in your timezone, transaction, response time and result."),
                div(style = "min-height:560px", DTOutput(ns("raw"))))
    )
  )
}

tables_server <- function(id, rv, settings) moduleServer(id, function(input, output, session) {
  refresh_picker(session, rv, input)
  chosen <- reactive({ req(input$file, input$file %in% names(rv$data)); rv$data[[input$file]]$dt })
  pipe   <- make_pipe(chosen, settings)

  output$agg <- renderDT({
    df <- pipe$by_label()
    dt_table(df, order = list(list(0, "asc"))) |>     # default sort by Label A-Z
      DT::formatString(c("Min", "Average", "p80", "p90", "p95", "Max"), suffix = " s") |>
      DT::formatString("Error%", suffix = "%")
  }, server = TRUE)
  output$err <- renderDT({
    e <- pipe$filtered()[ok == FALSE]
    if (!nrow(e)) return(dt_table(data.frame(Message = "No errors recorded")))
    dt_table(e[, .(Count = .N), by = .(Label = label, Code = code, Message = message)][order(-Count)])
  }, server = TRUE)
  output$raw <- renderDT({
    tz <- settings()$tz
    d  <- utils::tail(pipe$filtered(), 50000L)
    dt_table(d[, .(Time  = format(ts, "%d %b %Y %H:%M:%S", tz = tz),
                   Label = label, `RT (s)` = round(elapsed / 1000, 3),
                   OK = ok, Code = code)])
  }, server = TRUE)
})

# =====================================================================
# GRAPHS
# =====================================================================
graphs_ui <- function(id) {
  ns <- NS(id)
  tagList(
    file_picker(ns),
    navset_card_tab(
      nav_panel("Response Time Plot",
                intro("Every sampled response time across the test, downsampled to keep it responsive while preserving the shape. Red points are failures."),
                plotOutput(ns("scatter"), height = "560px")),
      nav_panel("Response Time Percentiles",
                intro("Average, 80th and 95th percentile response times over time. Dotted horizontal lines mark your SLA thresholds from Config."),
                plotlyOutput(ns("rt"), height = "560px")),
      nav_panel("Throughput",
                intro("Requests completed per second over the test."),
                plotlyOutput(ns("tp"), height = "560px")),
      nav_panel("Error rate",
                intro("Percentage of samples that failed, over time."),
                plotlyOutput(ns("er"), height = "560px")),
      nav_panel("Distribution",
                intro("How response times are spread across the test."),
                uiOutput(ns("dist_ui")))
    )
  )
}

graphs_server <- function(id, rv, settings, dark) moduleServer(id, function(input, output, session) {
  ns <- session$ns
  refresh_picker(session, rv, input)
  chosen <- reactive({ req(input$file, input$file %in% names(rv$data)); rv$data[[input$file]]$dt })
  pipe   <- make_pipe(chosen, settings)
  padr   <- reactive(pad_range(pipe$ts()$bucket, settings()$pad_s))

  output$rt <- renderPlotly(ply_rt(pipe$ts(), padr(),
                                    settings()$sla_p80, settings()$sla_p95, dark()))
  output$tp <- renderPlotly(ply_line(pipe$ts(), "throughput", "Requests / sec",
                                      pad = padr(), dark = dark()))
  output$er <- renderPlotly(ply_line(pipe$ts(), "error_rate", "Error rate (%)",
                                      color = "#E53935", pad = padr(), dark = dark()))

  # Distribution respects the static/interactive toggle.
  output$dist_ui <- renderUI(
    if (settings()$render_mode == "interactive") plotlyOutput(ns("dist_i"), height = "560px")
    else plotOutput(ns("dist_s"), height = "560px")
  )
  output$dist_s <- renderPlot({ dark(); gg_hist(jm_hist(pipe$filtered())) })
  output$dist_i <- renderPlotly({
    h <- jm_hist(pipe$filtered())
    plot_ly(h, x = ~mid, y = ~count, type = "bar", marker = list(color = ACCENT)) |>
      layout(xaxis = ply_axis("Response time (seconds)", NULL, dark()),
             yaxis = ply_axis("Count", NULL, dark())) |>
      ply_skin(dark())
  })

  # Raw scatter: downsample first, then draw statically.
  output$scatter <- renderPlot({
    dark()                                   # re-render on theme toggle (thematic recolors)
    d <- pipe$filtered()
    keep <- jm_lttb(d$ts, d$elapsed, threshold = 3000)
    ggplot(d[keep], aes(ts, elapsed / 1000, colour = ok)) +
      geom_point(alpha = 0.5, size = 0.8) +
      scale_colour_manual(values = c(`TRUE` = ACCENT, `FALSE` = "#E53935"), guide = "none") +
      labs(x = NULL, y = "Response time (seconds)") + gg_base()
  })
})

# =====================================================================
# COMPARISON
# =====================================================================
comparison_ui <- function(id) {
  ns <- NS(id)
  tagList(
    file_picker(ns, multiple = TRUE),
    selectInput(ns("baseline"), "Baseline test (drives the differences)", choices = NULL, width = "100%"),
    p(class = "text-muted small",
      "Select two or more files. Time charts are aligned to minutes into each run, so files from different days overlay cleanly."),
    navset_card_tab(
      nav_panel("Response Time Comparison",
                intro("Response times per transaction across the selected tests, grouped by metric so each test sits side by side. Transactions found in at least two tests are compared here; any found in only one are listed underneath. Use Column Visibility and the search boxes to focus."),
                div(style = "min-height:420px", DTOutput(ns("rt_match"))),
                tags$h6(class = "mt-3", "Transactions that cannot be compared"),
                p(class = "text-muted small", "Present in only one of the selected tests."),
                DTOutput(ns("rt_nonmatch"))),
      nav_panel("Response Time Difference",
                intro("The change in each metric versus the baseline, grouped by metric. Negative values (green) are improvements: faster response times or fewer errors."),
                div(style = "min-height:420px", DTOutput(ns("rt_diff")))),
      nav_panel("SLA compliance",
                intro("For each transaction, whether its 80th and 95th percentile met the SLA targets set in Config (including any per-transaction overrides), compared across tests. Green is a pass, red a fail. Transactions in only one test are listed underneath."),
                div(style = "min-height:420px", DTOutput(ns("sla_match"))),
                tags$h6(class = "mt-3", "Transactions that cannot be compared"),
                p(class = "text-muted small", "Present in only one of the selected tests."),
                DTOutput(ns("sla_nonmatch"))),
      nav_panel("Historical Trend",
                intro("Tracks the headline metrics across three or more runs in chronological order (by run id). Each chart has a plain-English summary beside it, so you can read the story without studying the graph."),
                layout_columns(
                  col_widths = c(9, 3),
                  plotlyOutput(ns("trend_rt"), height = "400px"),
                  card(card_header("Response time story"), uiOutput(ns("trend_rt_story")))),
                layout_columns(
                  col_widths = c(9, 3),
                  plotlyOutput(ns("trend_err"), height = "300px"),
                  card(card_header("Error rate story"), uiOutput(ns("trend_err_story"))))),
      nav_panel("p80 over time",
                intro("80th percentile response time over time, aligned to minutes into each run so tests from different days overlay."),
                plotlyOutput(ns("p80"), height = "520px")),
      nav_panel("p95 over time",
                intro("95th percentile response time over time, aligned to minutes into each run."),
                plotlyOutput(ns("p95"), height = "520px")),
      nav_panel("Throughput over time",
                intro("Requests per second over time, aligned to minutes into each run."),
                plotlyOutput(ns("tp"), height = "520px"))
    )
  )
}

# coloured delta formatting now lives in the shared builders (utils_jmeter.R).

comparison_server <- function(id, rv, settings, dark) moduleServer(id, function(input, output, session) {
  refresh_picker(session, rv, input, multiple = TRUE)
  sel <- reactive({ req(length(input$file) >= 1); intersect(input$file, names(rv$data)) })

  # keep the baseline picker in sync with the selected files
  observe({
    ch <- sel(); cur <- isolate(input$baseline)
    updateSelectInput(session, "baseline", choices = ch,
      selected = if (!is.null(cur) && cur %in% ch) cur else ch[1])
  })

  # Per-file artefacts: short tag, run summary, time series, per-label stats.
  # The chosen baseline is moved to the front so it drives the differences.
  files <- reactive({
    st <- settings(); nms <- sel()
    tags <- make.unique(vapply(nms, function(nm)
      rv$data[[nm]]$meta$run %||% nm, character(1)), sep = " ")
    lst <- Map(function(nm, tg) {
      d  <- jm_filter(rv$data[[nm]]$dt, st$exclude, st$rampup)
      ts <- jm_timeseries(d, st$bucket)
      ts$rel_min <- as.numeric(difftime(ts$bucket, min(ts$bucket), units = "mins"))
      list(name = nm, tag = tg, ts = ts, s = jm_summary(d),
           bl  = jm_by_label(d),
           sla = jm_sla_by_label(d, st$sla_p80, st$sla_p95, st$sla_overrides))
    }, nms, tags)
    names(lst) <- nms
    bl <- input$baseline
    if (!is.null(bl) && bl %in% nms) lst <- c(lst[bl], lst[setdiff(nms, bl)])
    unname(lst)
  })

  rt_built  <- reactive({ jm_compare_table(files()) })
  sla_built <- reactive({ jm_sla_compare_table(files(), settings()$sla_p80, settings()$sla_p95) })

  match_or_note <- function(built) {
    if (length(files()) < 2)
      return(dt_table(data.frame(Note = "Select at least two files to compare transactions.")))
    if (!nrow(built$df))
      return(dt_table(data.frame(Note = "No transactions are shared across the selected tests. See the list below.")))
    cmp_datatable(built)
  }
  diff_or_note <- function(built) {
    if (length(files()) < 2)
      return(dt_table(data.frame(Note = "Select at least two files to see differences.")))
    if (ncol(built$df) <= 1)
      return(dt_table(data.frame(Note = "No comparable transactions to difference.")))
    cmp_datatable(built)
  }
  output$rt_match  <- renderDT(match_or_note(rt_built()$values),  server = FALSE)
  output$rt_diff   <- renderDT(diff_or_note(rt_built()$diff),     server = FALSE)
  output$sla_match <- renderDT(match_or_note(sla_built()$values), server = FALSE)

  nonmatch_table <- function(single) {
    if (!nrow(single))
      return(dt_table(data.frame(Result = "Every transaction was found in at least two tests.")))
    dt_table(single)
  }
  output$rt_nonmatch  <- renderDT(nonmatch_table(rt_built()$single),  server = FALSE)
  output$sla_nonmatch <- renderDT(nonmatch_table(sla_built()$single), server = FALSE)

  # ---- overlaid time series (relative minutes) ----
  overlay <- function(field, ytitle) {
    xs <- files(); p <- plot_ly()
    for (x in xs) p <- add_lines(p, data = x$ts, x = ~rel_min,
                                 y = as.formula(paste0("~", field)), name = x$tag)
    layout(p, yaxis = ply_axis(ytitle, NULL, dark()),
           xaxis = ply_axis("Minutes into test", NULL, dark()),
           hovermode = "x unified") |> ply_skin(dark())
  }
  output$p80 <- renderPlotly(overlay("p80", "p80 response time (seconds)"))
  output$p95 <- renderPlotly(overlay("p95", "p95 response time (seconds)"))
  output$tp  <- renderPlotly(overlay("throughput", "Requests / sec"))

  # ---- historical trend across runs (chronological by run id) ----
  trend_data <- reactive({
    xs <- files()
    xs <- xs[order(vapply(xs, function(x) x$tag, character(1)))]   # chronological by run id
    data.frame(
      run = factor(vapply(xs, function(x) x$tag, character(1)),
                   levels = vapply(xs, function(x) x$tag, character(1))),
      avg = vapply(xs, function(x) x$s$mean, numeric(1)),
      p80 = vapply(xs, function(x) x$s$p80, numeric(1)),
      p95 = vapply(xs, function(x) x$s$p95, numeric(1)),
      err = vapply(xs, function(x) x$s$error_pct, numeric(1)))
  })
  trend_note <- function() plotly_empty(type = "scatter", mode = "markers") |>
    layout(title = list(text = "Select three or more tests to see a historical trend")) |>
    ply_skin(dark())

  output$trend_rt <- renderPlotly({
    if (length(files()) < 3) return(trend_note())
    d <- trend_data()
    plot_ly(d, x = ~run) |>
      add_trace(y = ~avg, name = "Average", type = "scatter", mode = "lines+markers", line = list(color = ACCENT)) |>
      add_trace(y = ~p80, name = "p80", type = "scatter", mode = "lines+markers", line = list(color = "#FB8C00")) |>
      add_trace(y = ~p95, name = "p95", type = "scatter", mode = "lines+markers", line = list(color = "#E53935")) |>
      layout(yaxis = ply_axis("Response time (seconds)", NULL, dark()),
             xaxis = c(ply_axis("Run", NULL, dark()), list(type = "category"))) |>
      ply_skin(dark())
  })
  output$trend_err <- renderPlotly({
    if (length(files()) < 3) return(trend_note())
    d <- trend_data()
    plot_ly(d, x = ~run, y = ~err, type = "scatter", mode = "lines+markers",
            line = list(color = "#E53935")) |>
      layout(yaxis = ply_axis("Error rate (%)", NULL, dark()),
             xaxis = c(ply_axis("Run", NULL, dark()), list(type = "category"))) |>
      ply_skin(dark())
  })
  # ---- storytelling blurbs (exec-summary style: bold leads + line breaks) ----
  story <- function(vals, fmt, lower_is_better, noun) {
    n <- length(vals); base <- vals[1]; last <- vals[n]
    d <- last - base
    improved <- if (lower_is_better) d < 0 else d > 0
    worse    <- if (lower_is_better) d > 0 else d < 0
    head <- if (improved) sprintf("%s improved overall, from %s to %s.", noun, fmt(base), fmt(last))
            else if (worse) sprintf("%s worsened overall, from %s to %s.", noun, fmt(base), fmt(last))
            else sprintf("%s stayed broadly flat across the runs.", noun)
    runs_lab <- as.character(trend_data()$run)
    lines <- list(tags$p(tags$strong("Baseline. "),
                         sprintf("%s started at %s.", runs_lab[1], fmt(base))))
    for (i in 2:n) {
      cur <- vals[i]; prev <- vals[i - 1]
      db <- cur - base; dp <- cur - prev
      rel <- function(delta) {
        better <- if (lower_is_better) delta < 0 else delta > 0
        if (delta == 0) return("level with")
        dir <- if (lower_is_better) (if (delta < 0) "faster" else "slower")
               else (if (delta > 0) "higher" else "lower")
        sprintf("%s %s than", fmt(abs(delta)), dir)
      }
      lines <- c(lines, list(tags$p(
        tags$strong(sprintf("%s. ", runs_lab[i])),
        sprintf("%s, %s baseline and %s the previous run.", fmt(cur), rel(db), rel(dp)))))
    }
    do.call(tags$div, c(list(tags$p(class = "lead", head)), lines))
  }
  output$trend_rt_story <- renderUI({
    if (length(files()) < 3) return(p(class = "text-muted", "Select three or more tests to see the story."))
    d <- trend_data(); n <- nrow(d); lab <- as.character(d$run)
    rel <- function(delta) {
      if (is.na(delta) || delta == 0) return("level with")
      sprintf("%s %s than", fmt_s(abs(delta)), if (delta < 0) "faster" else "slower")
    }
    trend_word <- function(delta) if (delta < 0) "improved" else if (delta > 0) "worsened" else "held steady"
    d80 <- d$p80[n] - d$p80[1]; d95 <- d$p95[n] - d$p95[1]
    head <- sprintf(
      "Across the runs the 80th percentile %s (%s to %s) and the 95th percentile %s (%s to %s).",
      trend_word(d80), fmt_s(d$p80[1]), fmt_s(d$p80[n]),
      trend_word(d95), fmt_s(d$p95[1]), fmt_s(d$p95[n]))
    lines <- list(tags$p(tags$strong("Baseline"), tags$br(),
      sprintf("80th: %s", fmt_s(d$p80[1])), tags$br(),
      sprintf("95th: %s", fmt_s(d$p95[1]))))
    for (i in 2:n) {
      lines <- c(lines, list(tags$p(
        tags$strong(lab[i]), tags$br(),
        sprintf("80th: %s, %s baseline and %s the previous run.",
          fmt_s(d$p80[i]), rel(d$p80[i] - d$p80[1]), rel(d$p80[i] - d$p80[i - 1])),
        tags$br(),
        sprintf("95th: %s, %s baseline and %s the previous run.",
          fmt_s(d$p95[i]), rel(d$p95[i] - d$p95[1]), rel(d$p95[i] - d$p95[i - 1])))))
    }
    do.call(tags$div, c(list(tags$p(class = "lead", head)), lines))
  })
  output$trend_err_story <- renderUI({
    if (length(files()) < 3) return(p(class = "text-muted", "Select three or more tests to see the story."))
    story(trend_data()$err, fmt_pct, lower_is_better = TRUE, noun = "The error rate")
  })
})
