# Performance Dashboard (JMeter, R Shiny)

A modern, responsive Shiny app for monitoring and reporting on JMeter CSV
results. Built for speed on files from 5 MB to 2 GB+. Handles one, two, or
many files, auto-detects the CSV schema, and exports a self-contained HTML
report you can hand to the team.

> Heads up: this v1 was written without running R locally (no R in the build
> sandbox). Treat it as a strong, complete first draft. Run it once, and if
> anything trips, paste the error back and it gets fixed fast.

## Run it

```r
install.packages(c(
  "shiny", "bslib", "bsicons", "data.table", "arrow", "DT",
  "plotly", "ggplot2", "scales", "thematic", "rmarkdown", "cachem"
))
# from this folder:
shiny::runApp()
```

Recommended versions: `bslib >= 0.6`, `data.table >= 1.15`, `arrow >= 14`.
HTML export needs Pandoc (bundled with RStudio; otherwise `install.packages("pandoc")`).

Click **Load sample data** on the Config tab to see it working with zero setup.

## Tabs

- **Config** - upload files, set timezone / bucket / SLA bands / exclude regex /
  ramp-up, choose static vs interactive rendering, export the HTML report.
- **Dashboard** - KPI value boxes (SLA-coloured), response time, throughput,
  error rate, top transactions.
- **Tables** - per-label aggregate, errors, raw samples (capped, server-side).
- **Graphs** - response time, throughput, active users, error rate,
  distribution, downsampled raw scatter.
- **Comparison** - select 2+ files, KPI deltas with win/loss colour, overlaid
  p95 and throughput.

## How it stays fast

1. **`data.table::fread` with column pruning** - only the columns the app uses
   are read. Far faster and lighter than `read_csv`.
2. **Parquet reload cache** - the first parse of a file is written to Parquet
   (keyed on a name+size+mtime fingerprint). Reopening or re-uploading the same
   file skips parsing entirely.
3. **Aggregate, then plot** - every time-series chart is built from a small
   per-bucket table (one row per 60 s by default), not the raw samples. A
   30-minute run becomes ~30 points. This is the main fix over the old app,
   which plotted every sample with plotly.
4. **Pre-binned histograms and LTTB downsampling** - the distribution chart
   plots pre-computed bins; the raw scatter is reduced to ~3,000 shape-preserving
   points before drawing.
5. **Server-side `DT`** - tables paginate in R, so the browser receives one page
   at a time, never millions of rows.
6. **Static rendering option** - heavy plots default to static PNG; flip to
   interactive when a file is small enough.
7. **Hidden tabs do no work** - Shiny suspends hidden outputs by default, so
   only the visible tab computes.

## Deliberate v1 simplifications (and how to scale further)

- **Synchronous ingest.** The first read of a 2 GB file blocks briefly behind a
  progress bar, then is cached. To make it fully non-blocking, wrap `jm_ingest`
  in a Shiny `ExtendedTask` (shiny >= 1.8.1) or `future`/`promises`. Marked in
  `config_server`.
- **In-memory canonical table.** Aggregation runs in `data.table` in RAM (fast).
  If a file is larger than available RAM, switch the aggregations to query the
  cached Parquet lazily with `arrow::open_dataset(...) |> dplyr::...`. Percentiles
  would then collect a downsampled subset. Hook point: `R/utils_jmeter.R`.
- **Raw viewer capped** at the most recent 50,000 rows for responsiveness. Raise
  or page from Parquet if you need the full set.

Re-profile hotspots with `profvis::profvis(shiny::runApp())`.

## File structure

```
app.R               assembles the navbar + wires modules to a shared store
global.R            packages, options, disk cache, theme, sample-data generator
R/utils_jmeter.R    the data engine (schema detect, ingest, aggregate, downsample)
R/modules.R         shared helpers + the five tab modules
report.Rmd          self-contained HTML export template
```

## What changed vs the old app (used as reference)

Kept the ideas that worked: percentile-based per-label stats, the ramp-up trim
and label exclude regex, the project/run/date filename parsing, the
five-section layout, and the green/orange/red comparison colouring.

Changed for performance and flexibility:

- `read_csv` -> `data.table::fread` + Parquet cache.
- Plotly scatter of every sample -> aggregated per-bucket charts + LTTB.
- Two fixed files (perf/comp) -> any number of files via a shared store.
- Hard-coded custom column names -> schema auto-detection (raw JMeter *and*
  your `startTime`/`TimeToLastByte`/`sampleLabel` exports both work).
- `shinydashboard` + fixed pixel widths -> `bslib` page_navbar with responsive
  `layout_columns` and `value_box`.
- Added the self-contained HTML export.

Response times are handled in **milliseconds** internally (JMeter's native unit),
which is why the SLA bands are 1500 / 3000 ms.
