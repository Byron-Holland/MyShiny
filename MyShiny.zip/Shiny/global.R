# =====================================================================
# global.R  -  shared setup, loaded once when the app starts
# ---------------------------------------------------------------------
# Performance philosophy (read this first):
#   1. Read fast        -> data.table::fread with column pruning.
#   2. Read once        -> cache the parsed/canonical data as Parquet,
#                          keyed on a file fingerprint, so reopening or
#                          re-uploading the same file is near-instant.
#   3. Aggregate first  -> every time-series chart plots a SMALL
#                          pre-aggregated table (one row per time bucket),
#                          never the millions of raw samples. This is the
#                          single biggest win over the old app.
#   4. Page, don't ship -> tables use server-side DT, so the browser only
#                          ever receives the current page.
#   5. Static escape    -> heavy views (distribution, raw scatter) can
#                          render as a static PNG to stay fast on huge files.
# =====================================================================

# Allow up to ~2.5 GB uploads.
options(shiny.maxRequestSize = 2.5 * 1024^3)

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)        # modern, responsive Bootstrap 5 UI + dark mode
  library(bsicons)      # icons for value boxes
  library(data.table)   # fast read + fast aggregation (the engine)
  library(arrow)        # Parquet reload cache
  library(DT)           # server-side tables
  library(plotly)       # interactive charts (only on aggregated data)
  library(ggplot2)      # static charts (the performance escape hatch)
  library(scales)       # axis formatting
  library(thematic)     # auto-themes ggplot to match light/dark mode
})

# Make static (ggplot) charts follow the active bslib theme, incl. dark mode.
thematic::thematic_shiny(font = "auto")

# Let data.table use all cores for reads and grouping.
data.table::setDTthreads(0L)

# ---- Disk cache (cross-session) -------------------------------------
# Parsed files are cached here as Parquet so we never re-parse a 2 GB
# CSV twice. Safe to delete this folder any time to reclaim space.
CACHE_DIR <- file.path(tempdir(), "jmeter_cache")
dir.create(CACHE_DIR, showWarnings = FALSE, recursive = TRUE)

# Shiny's bindCache backend (used for the heaviest reactives).
shinyOptions(cache = cachem::cache_disk(file.path(CACHE_DIR, "reactive")))

# ---- Theme ----------------------------------------------------------
# One place to change branding. Palette inspired by a clean fintech dashboard:
# navy brand bar, soft lavender page, white cards, vivid blue accent.
ACCENT  <- "#2F6BED"   # primary blue
NAVY    <- "#0F2A4A"   # brand / top bar
PAGE_BG <- "#EEF1F6"   # light page background
SURFACE <- "#FFFFFF"   # cards
BORDER  <- "#E3E8F0"
INK     <- "#1F2A37"
MUTED   <- "#8A93A3"
app_theme <- bs_theme(
  version       = 5,
  primary       = ACCENT,
  success       = "#16A34A",
  warning       = "#F59E0B",
  danger        = "#E5484D",
  base_font     = font_google("Inter"),
  heading_font  = font_google("Inter"),
  "border-radius" = "0.75rem"
)

# ---- Source the data engine and the UI modules ----------------------
source("R/utils_jmeter.R", local = FALSE)
source("R/modules.R",      local = FALSE)

# =====================================================================
# Sample data generator
# ---------------------------------------------------------------------
# Lets the app run end-to-end with zero setup. Writes a small synthetic
# JMeter-style CSV to a temp path and returns it. Point the Config tab's
# "Load sample data" button at this.
# =====================================================================
make_sample_csv <- function(n = 60000, minutes = 30, seed = 1) {
  set.seed(seed)
  t0   <- as.numeric(as.POSIXct("2026-06-19 09:00:00", tz = "Pacific/Auckland"))
  ts   <- sort(runif(n, t0, t0 + minutes * 60)) * 1000   # epoch MILLISECONDS (raw JMeter style)
  lab  <- sample(
    c("01_Login", "02_Search", "03_ViewItem", "04_AddToCart", "05_Checkout"),
    n, replace = TRUE, prob = c(.30, .25, .20, .15, .10)
  )
  base <- c("01_Login" = 320, "02_Search" = 600, "03_ViewItem" = 250,
            "04_AddToCart" = 480, "05_Checkout" = 1400)[lab]
  # Lognormal-ish response times with a slow tail; checkout degrades late in the run.
  drift   <- ifelse(lab == "05_Checkout", (ts/1000 - t0) / (minutes * 60) * 900, 0)
  elapsed <- round(pmax(5, base * rlnorm(n, 0, 0.45) + drift))
  ok      <- runif(n) > ifelse(lab == "05_Checkout", 0.04, 0.008)
  data.table(
    timeStamp       = sprintf("%.0f", ts),
    elapsed         = elapsed,
    label           = lab,
    responseCode    = ifelse(ok, "200", sample(c("500", "503", "408"), n, TRUE)),
    responseMessage = ifelse(ok, "OK", "Internal Server Error"),
    success         = tolower(as.character(ok)),
    allThreads      = pmin(50, 1 + floor((ts/1000 - t0) / 8)),
    Latency         = round(elapsed * 0.6)
  )
}

write_sample_csv <- function() {
  p <- file.path(tempdir(), "SampleProject_perf_20260619_0900.csv")
  data.table::fwrite(make_sample_csv(), p)
  p
}
