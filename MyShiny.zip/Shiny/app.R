# =====================================================================
# app.R  -  entry point. Run with: shiny::runApp() from this folder.
# =====================================================================
source("global.R")

ui <- page_navbar(
  title = "Performance Dashboard",
  theme = app_theme,
  fillable = FALSE,
  header = tags$head(tags$style(HTML("
    .cmp-sub { font-weight: 400; font-size: 0.78em; opacity: 0.72; }
    .section-intro { margin-top: 0.25rem; max-width: 70rem; }
    table.dataTable thead th { vertical-align: bottom; }

    /* Brand bar: navy in both modes for clear separation from the page */
    .navbar { background-color: #0F2A4A !important;
              box-shadow: 0 2px 10px rgba(15,42,74,.18); }
    .navbar .navbar-brand { color: #ffffff !important; font-weight: 700; letter-spacing: -.01em; }
    .navbar .nav-link { color: #b9c6dc !important; }
    .navbar .nav-link:hover { color: #ffffff !important; }
    .navbar .nav-link.active { color: #ffffff !important; font-weight: 600; }

    /* Light-mode polish (scoped so the dark theme is untouched) */
    [data-bs-theme=light] body { background: #EEF1F6; }
    [data-bs-theme=light] .card,
    [data-bs-theme=light] .bslib-value-box,
    [data-bs-theme=light] .navset-card-tab,
    [data-bs-theme=light] .nav-panel > .card {
      border: 1px solid #E3E8F0;
      box-shadow: 0 1px 3px rgba(16,42,74,.05), 0 1px 2px rgba(16,42,74,.04);
    }
    [data-bs-theme=light] .card-header { background: #F7F9FC; border-bottom: 1px solid #E9EEF5; font-weight: 600; }
    [data-bs-theme=light] table.dataTable thead th { background: #F7F9FC; }
    [data-bs-theme=light] .nav-pills .nav-link.active,
    [data-bs-theme=light] .nav-tabs .nav-link.active { color: #2F6BED; }

    /* Config controls share the brand palette */
    .shiny-file-input-progress .progress-bar,
    .shiny-file-input-progress .progress-bar-success,
    .shiny-file-input-progress .bg-success { background-color: #2F6BED !important; color: #fff !important; }
    .form-check-input:checked { background-color: #2F6BED !important; border-color: #2F6BED !important; }
    .form-check-input:focus { border-color: #2F6BED; box-shadow: 0 0 0 .2rem rgba(47,107,237,.25); }
    #cfg-export.btn-primary, .btn-primary { background-color: #2F6BED; border-color: #2F6BED; }
    #cfg-export.btn-primary:hover, .btn-primary:hover { background-color: #2457c9; border-color: #2457c9; }
  "))),
  nav_panel("Config",     icon = bs_icon("gear"),        config_ui("cfg")),
  nav_panel("Exec Summary", icon = bs_icon("clipboard-check"), execsummary_ui("exec")),
  nav_panel("Dashboard",  icon = bs_icon("speedometer2"), dashboard_ui("dash")),
  nav_panel("Tables",     icon = bs_icon("table"),        tables_ui("tbl")),
  nav_panel("Graphs",     icon = bs_icon("graph-up"),     graphs_ui("gr")),
  nav_panel("Comparison", icon = bs_icon("bar-chart-line"), comparison_ui("cmp")),
  nav_spacer(),
  nav_item(input_dark_mode(id = "color_mode"))
)

server <- function(input, output, session) {
  # Shared store: rv$data = loaded datasets, rv$pending = files awaiting mapping.
  rv <- reactiveValues(data = list(), pending = list())

  settings <- config_server("cfg", rv)   # Config owns uploads + settings
  dark <- reactive(identical(input$color_mode, "dark"))
  execsummary_server("exec", rv, settings)
  dashboard_server("dash", rv, settings, dark)
  tables_server("tbl", rv, settings)
  graphs_server("gr", rv, settings, dark)
  comparison_server("cmp", rv, settings, dark)
}

shinyApp(ui, server)
